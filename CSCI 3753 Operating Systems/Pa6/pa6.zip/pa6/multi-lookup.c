
#include "multi-lookup.h"
#include "array.h"

// Producer reads from input files, puts on shared buffer using array_put, and writes to services.txt

void* requesters(void* s) {
    struct timeval start, end;
    gettimeofday(&start, NULL);
    multithread* data = (multithread*)s;
    int count = 0;
    int indexL = 0;
    while (1) {
        sem_wait(&(data->fileLock));
        indexL = data->index;
        if (indexL >= data->fileCount) {
            sem_post(&(data->fileLock));
            gettimeofday(&end, NULL);
            double runtime = (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1000000.0;
            printf("Thread %lx serviced %d files in %lf\n", pthread_self(), count, runtime);
            fflush(stderr);
            return NULL;
        }
        sem_post(&(data->fileLock));
        sem_wait(&(data->fileLock));
                data->index++;
        sem_post(&(data->fileLock));

        char* filename = data->inputFile[indexL];
        FILE* fd = fopen(filename, "r+");
        if (fd == NULL) {
            fflush(stderr);
            continue; // Skip this file
        }

        char hostname[MAX_NAME_LENGTH];
        while (fgets(hostname, sizeof(hostname), fd)) {
            if (hostname[0] != '\n') {
                hostname[strlen(hostname) - 1] = '\0';

                // Add hostname to the shared buffer
                // sem_wait(&(data->sharedBuffer->sp_avail));
                // sem_wait(&(data->sharedBuffer->mutex));
                array_put(data->sharedBuffer, hostname);
                // if (array_put(data->sharedBuffer, hostname) == -1) {
                    // sem_post(&(data->sharedBuffer->mutex));
                    // sem_post(&(data->sharedBuffer->item_avail));
                // }
                sem_wait(&(data->serviceLock));
                fprintf(data->serviceTxt, "%s\n", hostname);
                fflush(stderr);
                sem_post(&(data->serviceLock));

                    // sem_post(&(data->sharedBuffer->mutex));
                    // sem_post(&(data->sharedBuffer->item_avail));
                // }
            }
        }

        fclose(fd);
        count++;
    }

    return NULL;
}
void* resolvers(void* s) {
    struct timeval start, end;
    gettimeofday(&start, NULL);
    multithread* data = (multithread*)s;
    char* hostname = malloc(MAX_NAME_LENGTH);
    char *ip = malloc(MAX_IP_LENGTH);
    int count = 0;
    if(hostname == NULL || ip == NULL) {
        exit(-1);
    }
    while (1) {

        // Get hostname from the shared buffer
        // sem_wait(&(data->sharedBuffer->item_avail));
        // sem_wait(&(data->sharedBuffer->mutex));

        if (array_get(data->sharedBuffer, &hostname) == -1) {
            // Buffer is empty, check for poison pill
            
            // sem_post(&(data->sharedBuffer->mutex));
            // sem_post(&(data->sharedBuffer->sp_avail));
            continue; // DNS NOT FOUND
        }
        if (sem_trywait(&(data->poisonPill)) == 0) {
                // Poison pill detected, exit the thread
                // sem_post(&(data->sharedBuffer->mutex));
                // sem_post(&(data->sharedBuffer->sp_avail));
                gettimeofday(&end, NULL);
                double runtime = (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1000000.0;
                printf("Thread %lx resolved %d hostnames in %lf\n", pthread_self(), count,runtime);
                free(hostname);
                free(ip);
                return NULL;
        }
        // sem_post(&(data->sharedBuffer->mutex));
        // sem_post(&(data->sharedBuffer->item_avail));

        // Resolve hostname to IP address
        if(dnslookup(hostname, ip, MAX_IP_LENGTH) == 0){
            sem_wait(&(data->resultsLock));
            fprintf(data->resolverTxt, "%s, %s\n", hostname, ip);
            fflush(stderr);
            count++;
            sem_post(&(data->resultsLock));

        }else{
            sem_wait(&(data->resultsLock));
            // fprintf(stderr, "DNS lookup failed for %s:\n", hostname);
            fflush(stderr);
            sem_post(&(data->resultsLock));
        }

        // Write results to the resolver log
        // sem_wait(&(data->resultsLock));
        // fprintf(data->resolverTxt, "%s, %s\n", hostname, ip);
        // fflush(data->resolverTxt);
        // sem_post(&(data->resultsLock));

        // if (hostname != NULL) {
        //     free(hostname);
        // }
    }

    return NULL;
}



int main(int argc, char* argv[]) {
    printf("<Main> start: ");
    struct timeval start, end;
    printf("Requester start: ");
    gettimeofday(&start, NULL);    
    if (argc < 6) {
        printf("Not enough argc");
        return -1;
    }
    int numRequesters = atoi(argv[1]);
    int numResolvers = atoi(argv[2]);

    if (numRequesters > MAX_REQUESTER_THREADS || numResolvers > MAX_RESOLVER_THREADS || numRequesters < 1 || numResolvers < 1) {
        fprintf(stderr, "Error: Invalid num of threads\n");
        exit(EXIT_FAILURE);
    }

    multithread mt;
    mt.serviceTxt = fopen(argv[3], "w");
    mt.resolverTxt = fopen(argv[4], "w");
    mt.inputFile = &argv[5];

    mt.index = 0;
    mt.fileCount = argc - 5;

    sem_init(&mt.fileLock, 0, 1);
    sem_init(&mt.serviceLock, 0, 1);
    sem_init(&mt.resultsLock, 0, 1);
    sem_init(&mt.poisonPill, 0,0);
    array sharedBuffer;
    array_init(&sharedBuffer);
    mt.sharedBuffer = &sharedBuffer;

    pthread_t requesterThreads[numRequesters];
    pthread_t resolverThreads[numResolvers];

    for (int i = 0; i < numRequesters; i++) {
        pthread_create(&requesterThreads[i], NULL, requesters, &mt);
    }

    for (int i = 0; i < numResolvers; i++) {
        pthread_create(&resolverThreads[i], NULL, resolvers, &mt);
    }
    for (int i = 0; i < numRequesters; i++) {
        pthread_join(requesterThreads[i], NULL);
    }
    for(int i = 0; i < numResolvers; i++){
        // array_put(&sharedBuffer, "POISON PILL"); /*POSION PILL*/
        sem_post(&mt.poisonPill);

    }
    for (int i = 0; i < numResolvers; i++) {
        pthread_join(resolverThreads[i], NULL);
    }
    sem_destroy(&mt.fileLock);
    sem_destroy(&mt.serviceLock);
    sem_destroy(&mt.resultsLock);
    sem_destroy(&mt.poisonPill);
    array_free(&sharedBuffer);
    fclose(mt.serviceTxt);
    fclose(mt.resolverTxt);
    gettimeofday(&end, NULL);
    double runtime = (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1000000.0;
    printf("Total time is %lf seconds\n", runtime);
    return 0;
}   